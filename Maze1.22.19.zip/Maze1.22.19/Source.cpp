//Lauren Bolin
#include "Maze.h"
#include <iostream>
using namespace std;

void main()
{
	Maze maze;
	maze.playGame();
}